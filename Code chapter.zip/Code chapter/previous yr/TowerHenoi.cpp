#include <bits/stdc++.h>
using namespace std;

void moveDisk(stack<int> &src,
              stack<int> &dest,
              char s,
              char d)
{
    int pole1Top;
    int pole2Top;

    if (src.empty())
    {
        pole1Top = INT_MAX;
    }
    else
    {
        pole1Top = src.top();
    }

    if (dest.empty())
    {
        pole2Top = INT_MAX;
    }
    else
    {
        pole2Top = dest.top();
    }

    if (pole1Top < pole2Top)
    {
        dest.push(src.top());

        cout << "Move Disk "
             << src.top()
             << " from "
             << s
             << " to "
             << d
             << endl;

        src.pop();
    }
    else
    {
        src.push(dest.top());

        cout << "Move Disk "
             << dest.top()
             << " from "
             << d
             << " to "
             << s
             << endl;

        dest.pop();
    }
}

int main()
{
    int n;

    cout << "Enter Number of Disks: ";
    cin >> n;

    stack<int> src, dest, aux;

    for (int i = n; i >= 1; i--)
    {
        src.push(i);
    }

    int totalMoves = pow(2, n) - 1;

    char S = 'A';
    char D = 'C';
    char A = 'B';

    if (n % 2 == 0)
    {
        swap(D, A);
    }

    for (int i = 1; i <= totalMoves; i++)
    {
        if (i % 3 == 1)
        {
            moveDisk(src, dest, S, D);
        }
        else if (i % 3 == 2)
        {
            moveDisk(src, aux, S, A);
        }
        else
        {
            moveDisk(aux, dest, A, D);
        }
    }

    return 0;
}