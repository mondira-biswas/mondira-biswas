#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node *left;
    Node *right;
};
 
void preorder(Node *root )
{
    if( root !=NULL)
    {
        cout<<root->data<<" ";
        preorder(root->left);
        preorder(root->right);


    }
}
void inorder(Node *root)
{
    if(root !=NULL)
    {
        inorder(root->left);
        cout<<root->data<<" ";
        inorder(root->right);
    }
}
void postorder(Node *root)
{
    if(root !=NULL)
    {
        inorder(root->left);
        inorder(root->right);
        cout<<root->data<<" ";
    }
}

int main()
{
    Node *root = new Node{1,NULL,NULL};

    root->left = new Node{12,NULL,NULL};
    root->right = new Node{9,NULL,NULL};

    root->left->left = new Node{5,NULL,NULL};
    root->left->right = new Node{6, NULL, NULL};

    cout<<"\n preorder:";
    preorder(root);

    cout<<"\n inorder:";
    inorder(root);

    cout<<"\n postorder:";
    postorder(root);

    return 0;

}


