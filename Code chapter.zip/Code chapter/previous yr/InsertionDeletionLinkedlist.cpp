#include<bits/stdc++.h>
using namespace std;

struct Node
{
    int data;
    Node *next;
};

Node *head = NULL;
Node *tail =NULL;

// Insert at begginging
 void push_front(int val)
 {
    Node *newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if(head==NULL)
    {
        head = tail=newNode;
    }
    else{
        newNode->next = head;
        head = newNode;
    }

 }
 //insert at end
 void push_back(int val)
 {
    Node *newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;
    
    if(head==NULL)
    {
        head = tail = newNode;
    }
    else
    {
        tail->next = newNode;
        tail = newNode;
    }
 }
 //Insert after nth node
 void insertAfter(int pos ,int val)
 {
    Node *temp = head;
    for(int i =1;i<pos && temp !=NULL;i++)
    {
        temp = temp->next;
    }
    if(temp == NULL)
    return;

    Node *newNode = new Node;
    newNode->data = val;

    newNode->next = temp->next;
    temp->next = newNode;

    if(temp==tail)
    tail = newNode;

 }
 //delete from beggining
 void pop_front()
 {
    if(head==NULL)
    return;

    Node *temp = head;
    head = head->next;
    delete temp;
    if(head ==NULL)
    tail = NULL;
 }
 //delete from end
 void pop_back()
 {
    if(head == NULL)
    return ;
    
    if(head==tail)
    {
        delete head;
        head = tail=NULL;
        return;
    }
    Node *temp = head;
    while(temp->next !=tail)
    {
        temp = temp->next;
    }
    delete tail;
    tail = temp;
    tail->next = NULL;
 }
 //delete from nth node
 void deletePosition(int pos)
 {
    if(head==NULL)
    return;

    if(pos==1)
    {
        pop_front();
        return;
    }
    Node *temp = head;
    for(int i =1;i<pos-1 && temp !=NULL;i++)
    {
        temp = temp->next;
    }
    if(temp == NULL|| temp->next==NULL)
    return;

    Node *delNode = temp->next;
    temp->next = delNode->next;

    if(delNode==tail)
    tail=temp;

    delete delNode;
}
///display linked list

void printLL()
{
    Node *temp = head;

    while(temp !=NULL)
    {
        cout<<temp->data<<" ->";
        temp = temp->next;
    }
    cout<<"NULL"<<endl;
}


int main()
{
    cout<<"1. Insert 10 at start"<<endl;

    head = tail= NULL;
    push_back(20);
    push_back(30);
    push_front(10);
    printLL();

    cout<<endl;
    cout<<"2.Insert 50 at end"<<endl;
     
    push_back(50);
    printLL();

    cout<<endl;
    cout<<"3. Insert 40 after 3rd node"<<endl;

    insertAfter(3,40);
    printLL();

    cout<<endl;
    cout<<"4.Delete from start "<<endl;

    head = tail= NULL;
    push_back(10);
    push_back(20);
    push_back(30);

    pop_front();
    printLL();
    cout << endl;
    cout << "5. Delete from End" << endl;

    head = tail = NULL;
    push_back(20);
    push_back(30);
    push_back(40);

    pop_back();
    printLL();

    cout << endl;
    cout << "6. Delete 3rd Node" << endl;

    head = tail = NULL;
    push_back(20);
    push_back(30);
    push_back(50);
    push_back(60);

    deletePosition(3);
    printLL();

    return 0;
}

 
