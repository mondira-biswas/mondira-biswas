#include <iostream>
using namespace std;

#define MAX 5

class Deque
{
    int arr[MAX];
    int front, rear;

public:
    Deque()
    {
        front = -1;
        rear = -1;
    }

    void insertFront(int x)
    {
        if ((front == 0 && rear == MAX - 1) || (front == rear + 1))
        {
            cout << "Deque Overflow\n";
            return;
        }

        if (front == -1)
        {
            front = rear = 0;
        }
        else if (front == 0)
        {
            front = MAX - 1;
        }
        else
        {
            front--;
        }

        arr[front] = x;
    }

    void insertRear(int x)
    {
        if ((front == 0 && rear == MAX - 1) || (front == rear + 1))
        {
            cout << "Deque Overflow\n";
            return;
        }

        if (front == -1)
        {
            front = rear = 0;
        }
        else if (rear == MAX - 1)
        {
            rear = 0;
        }
        else
        {
            rear++;
        }

        arr[rear] = x;
    }

    void deleteFront()
    {
        if (front == -1)
        {
            cout << "Deque Underflow\n";
            return;
        }

        cout << "Deleted from Front: " << arr[front] << endl;

        if (front == rear)
        {
            front = rear = -1;
        }
        else if (front == MAX - 1)
        {
            front = 0;
        }
        else
        {
            front++;
        }
    }

    void deleteRear()
    {
        if (front == -1)
        {
            cout << "Deque Underflow\n";
            return;
        }

        cout << "Deleted from Rear: " << arr[rear] << endl;

        if (front == rear)
        {
            front = rear = -1;
        }
        else if (rear == 0)
        {
            rear = MAX - 1;
        }
        else
        {
            rear--;
        }
    }

    void display()
    {
        if (front == -1)
        {
            cout << "Deque is Empty\n";
            return;
        }

        cout << "Deque Elements: ";

        int i = front;
        while (true)
        {
            cout << arr[i] << " ";

            if (i == rear)
                break;

            i = (i + 1) % MAX;
        }

        cout << endl;
    }
};

int main()
{
    Deque dq;

    dq.insertRear(10);
    dq.insertRear(20);
    dq.insertFront(5);
    dq.insertFront(2);

    dq.display();

    dq.deleteFront();
    dq.deleteRear();

    dq.display();

    return 0;
}