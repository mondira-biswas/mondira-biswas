// Suppose you have a linked list L and an avail list A.You want to insert a new item N from avail list A to the linked list at the position after X and before Y where X and Y are consecutive items in linked list L.Write a program to insert this new item N into the list L and update the avail list.
#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node *next;
};

Node *AVAIL = NULL;

void insertNode(Node *&head, int X, int N)
{

    if (AVAIL == NULL)
    {
        cout << "AVAIL list is empty!" << endl;
        return;
    }

    Node *NEW = AVAIL;
    AVAIL = AVAIL->next;

    NEW->data = N;

    Node *ptr = head;

    while (ptr != NULL && ptr->data != X)
        ptr = ptr->next;

    if (ptr == NULL)
    {
        cout << "X not found!" << endl;
        return;
    }

    NEW->next = ptr->next;
    ptr->next = NEW;
}

void display(Node *head)
{
    while (head != NULL)
    {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

int main()
{

    Node *head = new Node{10, NULL};
    head->next = new Node{20, NULL};
    head->next->next = new Node{30, NULL};

    AVAIL = new Node;
    AVAIL->next = NULL;

    insertNode(head, 20, 25);

    cout << "Updated List: ";
    display(head);

    return 0;
}