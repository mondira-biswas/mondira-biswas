#include <iostream>
using namespace std;

#define SIZE 5

int cq[SIZE];
int front = -1;
int rear = -1;

void enqueue(int value)
{
    if ((rear + 1) % SIZE == front)
    {
        cout << "Queue Full" << endl;
        return;
    }

    if (front == -1)
    {
        front = rear = 0;
    }
    else
    {
        rear = (rear + 1) % SIZE;
    }

    cq[rear] = value;
}

void dequeue()
{
    if (front == -1)
    {
        cout << "Queue Empty" << endl;
        return;
    }

    cout << "Deleted Element: "
         << cq[front] << endl;

    if (front == rear)
    {
        front = rear = -1;
    }
    else
    {
        front = (front + 1) % SIZE;
    }
}

void display()
{
    if (front == -1)
    {
        cout << "Queue Empty" << endl;
        return;
    }

    int i = front;

    while (true)
    {
        cout << cq[i] << " ";

        if (i == rear)
            break;

        i = (i + 1) % SIZE;
    }

    cout << endl;
}

int main()
{
    enqueue(10);
    enqueue(20);
    enqueue(30);
    enqueue(40);

    cout << "Queue: ";
    display();

    dequeue();

    cout << "After Dequeue: ";
    display();

    enqueue(50);
    enqueue(60);

    cout << "Final Queue: ";
    display();

    return 0;
}