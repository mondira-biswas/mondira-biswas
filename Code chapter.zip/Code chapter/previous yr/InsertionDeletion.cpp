#include<iostream>
#include<string>
using namespace std;
int main()
{
    string arr[10] = {"BBBB","DDDD","MMMM","XXXX"};
    int n = 4;
      
    //insert FFFF
    string item = "FFFF";
    int pos = 0;

    while(pos<n && arr[pos]<item)
    pos++;

    for(int i = n;i>pos;i--)
    arr[i] = arr[i-1];

    arr[pos]= item;
    n++;
    
    //insert ZZZZ
      item = "ZZZZ";
       pos = 0;

    while(pos<n && arr[pos]<item)
    pos++;

    for(int i =n;i>pos;i--)
    arr[i]= arr[i-1];

    arr[pos]= item;
    n++;

    cout<<"After insertion:\n";
    for(int i=0;i<n;i++)
    cout<<arr[i]<<endl;
//delete MMMM
    string delItem = "MMMM";
    int delpos=-1;

    for(int i =0;i<n;i++)
    {
        if(arr[i]==delItem)
        {
            delpos=i;
            break;
        }
    }
    if(delpos !=-1)
    {
        for(int i = delpos;i<n-1;i++)
        arr[i]=arr[i+1];
        n--;
    }
    cout<<"\n After deletion:\n";
    for(int i =0;i<n;i++)
    cout<<arr[i]<<endl;
    
    return 0;
   





}