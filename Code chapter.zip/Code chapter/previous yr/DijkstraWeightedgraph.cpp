#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m;

    cout << "Enter Nodes and Edges: ";
    cin >> n >> m;

    vector<pair<int, int>> adj[n + 1];

    cout << "Enter Edges (u v w):" << endl;

    for (int i = 0; i < m; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;

        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }

    int source;

    cout << "Enter Source Node: ";
    cin >> source;

    vector<int> dist(n + 1, INT_MAX);

    priority_queue<
        pair<int, int>,
        vector<pair<int, int>>,
        greater<pair<int, int>>>
        pq;

    dist[source] = 0;

    pq.push({0, source});

    while (!pq.empty())
    {
        int d = pq.top().first;
        int u = pq.top().second;

        pq.pop();

        for (auto edge : adj[u])
        {
            int v = edge.first;
            int w = edge.second;

            if (dist[v] > dist[u] + w)
            {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }

    cout << "\nShortest Distance:\n";

    for (int i = 1; i <= n; i++)
    {
        cout << "Node " << i
             << " = "
             << dist[i]
             << endl;
    }

    return 0;
}