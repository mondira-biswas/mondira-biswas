// Write a program that provides the 
// post - order tree traversing from the following numbers 44, 30, 50, 22, 60, 55, 77, and 57.
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *left, *right;
};

struct node *newNode(int data)
{
    struct node *temp = (struct node *)malloc(sizeof(struct node));
    temp->data = data;
    temp->left = temp->right = NULL;
    return temp;
}

struct node *insert(struct node *root, int data)
{
    if (root == NULL)
        return newNode(data);

    if (data < root->data)
        root->left = insert(root->left, data);
    else
        root->right = insert(root->right, data);

    return root;
}

void postOrder(struct node *root)
{
    if (root != NULL)
    {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d ", root->data);
    }
}

int main()
{
    int arr[] = {44, 30, 50, 22, 60, 55, 77, 57};
    int n = 8;

    struct node *root = NULL;

    for (int i = 0; i < n; i++)
        root = insert(root, arr[i]);

    printf("Postorder Traversal: ");
    postOrder(root);

    return 0;
}